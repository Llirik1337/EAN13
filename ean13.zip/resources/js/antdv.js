import Vue from "vue";
import Antd from "ant-design-vue";

// import {
//     Menu,
//     Form,
//     Input,
//     Row,
//     Col,
//     Checkbox,
//     Button,
//     Icon,
//     Layout,
//     Table,
//     Alert,
//     List,
//     Popconfirm,
//     message
// } from "ant-design-vue";
Vue.use(Antd);
// Vue.use(Menu);
// Vue.use(Form);
// Vue.use(Input);
// Vue.use(Row);
// Vue.use(Col);
// Vue.use(Checkbox);
// Vue.use(Button);
// Vue.use(Icon);
// Vue.use(Layout);
// Vue.use(Table);
// Vue.use(Alert);
// Vue.use(List);
// Vue.use(Popconfirm);
// Vue.prototype.$message = message;
